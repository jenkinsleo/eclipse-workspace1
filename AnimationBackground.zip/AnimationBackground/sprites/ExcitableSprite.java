
public interface ExcitableSprite {

	public boolean getIsHappy();
	public void setIsHappy(boolean isHappy);
		
	public boolean getIsEnergetic();
	public void setIsEnergetic(boolean isEnergetic);

	public void dance(double seconds);
	
}
